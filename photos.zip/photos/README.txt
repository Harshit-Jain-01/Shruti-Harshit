DROP YOUR 9 PHOTOS HERE.

Rename them exactly like this (jpg, lowercase):

  1.jpg   → Starbucks coffee date
  2.jpg   → BeReal Pune dinner table
  3.jpg   → solo café portrait of you
  4.jpg   → hike selfie hugging
  5.jpg   → silly tongue/funny faces selfie
  6.jpg   → her with the rescued cat in rain
  7.jpg   → cheek-to-cheek sweet selfie
  8.jpg   → nose-squish funny moment
  9.jpg   → final sweet smile selfie

(Order doesn't actually matter — you can shuffle. Each filename maps to
the caption in the same position on the site, which you can change by
editing the PHOTOS array near the bottom of index.html.)

Once the photos are in this folder, upload the WHOLE parent folder
(the one containing index.html AND this photos folder) to your host.

Without photos the site still works — each polaroid just shows a
placeholder until you add the files.
